#include <stdlib.h>
#include <stdio.h>
#include "repository.h"

typedef struct dummy_node {
	int key;
	int data;
	struct dummy_node *next;
} node;

unsigned long int counter;

node empty_head;

void Repository_init();
int Repository_update(int key, int data);
int Repository_delete(int key);
int Repository_get(int key, int *data);
void Repository_print(int print_elements);


void Repository_init() {
	counter = 0;

	empty_head.next = NULL;
}


int Repository_update( int key, int data) {
	node *new;
	node *curr;

	curr = &empty_head;

	while(curr->next != NULL && curr->next->key < key) {
		/*point curr to next*/
		curr = curr->next;
		counter++;
	}

	if(curr->next == NULL || curr->next->key > key) {
		/*getting new node ready*/
		new = malloc(sizeof(node));
		if (new == NULL) return -1;

		new->key = key;
		new->data = data;

		/*connect new node before next node*/
		new->next = curr->next;
		/*connect new node after previous node*/
		curr->next = new;
		return 1;
	} else {

		curr->next->data = data;
	
		return 0;
	}	
}

int Repository_delete(int key) {
	
	node *delete;
	node *curr;

	curr = &empty_head;

	while(curr->next != NULL && curr->next->key <= key) {

		if (curr->next->key == key) {
			delete = curr->next;
			curr->next = delete->next;
			free(delete);
			return 1;
		}

		/*point curr to next*/
		curr = curr->next;
		counter++;
	}

	return 0;
}

int Repository_get(int key, int *data) {
	node *curr;

	curr = &empty_head;

	while(curr->next != NULL && curr->next->key <= key) {

		if (curr->next->key == key) {

			*data = curr->next->data;
			return 1;
		}

		/*point curr to next*/
		curr = curr->next;
		counter++;

	}
	return 0;
}

void Repository_print(int print_elements) {

	int size = 0;

	if (print_elements == 0) {
		/*print size of list and counter*/

		node *curr;

		curr = empty_head.next;

		while(curr != NULL) {
			size++;
			curr = curr->next;
		
			printf("Sorted repository has %d elements with %lu steps performed.", size, counter);
		}

	} else {
		/*print all list*/

		node *curr;

		curr = empty_head.next;
		
		printf("Elements:\t");
		

		while(curr != NULL) {
			size++;
			printf("{%d, %d}", curr->key, curr->data);

			curr = curr->next;
		}	
		
		printf("Repo has %d elements with %lu steps.\n",size, counter);
		

	}
}
