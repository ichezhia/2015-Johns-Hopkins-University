#ifndef INC_COURSE
#define INC_COURSE
#include <stack>
#include <string>
#include "Fact.h"

using namespace std;
using std::string;

class Course {
public: 
	Course(string subject = "", string courseName = "", int numericGrade = 0);

	//functions
	void setSubjectName(const string &);
	void setCourseName(const string &);

	string getCourseName();
	string getSubjectName();
	void study();
	void addFact(Fact*);

	int takeExam();
	void setNumericGrade(const int &);
	char calculateLetterGrade();

private:
	string courseName;
	string subject;
	
	stack<Fact*> s;
	stack<Fact*> temp;

	int numericGrade;
	char letterGrade;
};

#endif
