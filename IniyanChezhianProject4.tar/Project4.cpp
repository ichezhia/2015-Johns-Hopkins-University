#define EXIT_SUCCESS
#include <cstdlib>
#include <iostream>

#include <string>
using std::string;

#include "Student.h"
#include "Course.h"


using namespace std;

main()
{
	Student student;

	int choice;
	int subjectChoice;	
	//string subjectName;
	//string courseName;
	int courseNumber;
	
	do {
		cout << "Project 4 - Main Menu\n\n";
		
		cout << "1. Add a Course\n";
		cout << "2. Drop a Course\n";
		cout << "3. Study for a Course\n";
		cout << "4. Take Exam for a Course\n";
		cout << "5. Ask Professor for Grading Rubric\n";
		cout << "6. Calculate and show course grades\n";
		cout << "7. Take Finals and Finish the Semester\n";
		cout << "8. Exit\n";

		cout << "\nEnter a choice (1-8): ";

		cin >> choice;
	
		cout << "\n";

		//validate
		while((choice<1) || (choice>8)) {
			cout << "\nEnter a choice (1-8): ";
			cin >> choice;
		}

		switch (choice) {
			case 1 : {
				
				cout << "\nSubjects\n";
				
				cout << "1.Physics\n";
				cout << "2.History\n";
				cout << "3.Math\n";
				cout << "4.Biology\n";
				cout << "5.Art\n";
				cout << "6.Computer Science\n";

				cout << "\nEnter a subject (1-6): ";
				cin >> subjectChoice;

				//validate
				while((subjectChoice<1) || (choice>6)) {
					cout << "\nEnter a subject (1-6): ";
					cin >> subjectChoice;
				}

				string subjectName;
				string courseName;

				switch(subjectChoice) {
					case 1 : subjectName = "physics";
						break;
					case 2 : subjectName = "history";
						break;
					case 3 : subjectName = "math";
						break;
					case 4 : subjectName = "biology";
						break;
					case 5 : subjectName = "art";
						break;
					case 6 : subjectName = "computer science";
						break;
				}

				cout << "Enter course name for " << subjectName << ": ";
				
				cin >> courseName;

				//new course pointer
				Course *courseTemp;
				courseTemp = new Course(subjectName, courseName);

				cout << "\n";
				
				//add pointer to student and print all courses
				cout << student.addCourse(courseTemp) << "\n\n";
				student.printCourseNames();

				cout << "\n";
			}
				break;

			case 2 : {
			
				student.printCourseNames();
				cout << "\nEnter course number to drop: ";

				cin >> courseNumber;
			
				cout << "\n" << student.dropCourse(courseNumber) << "\n\n";

				student.printCourseNames();
				cout << "\n";
			}
				break;

			case 3 : {
				student.printCourseNames();

				cout << "\nEnter course number to study for: ";
				cin >> courseNumber;

				cout << "\n";

				student.study(courseNumber);

				cout << "\n\n";
		
			}
				break;

			case 4 : {
				student.printCourseNames();

				cout << "\nEnter course number to take exam for: ";
				cin >> courseNumber;
				
				student.takeCourseExam(courseNumber);

			}
				break;

			case 5 : {
					
				student.getRubric();


			}
				break;
			case 6 : {

				student.getGrades();
				cout << "\n";
			}
				break;

			case 7 : {

				student.takeFinals();
			}
				break;

			case 8  :  {
				exit(0);
			}
		}
	} while(1);
}
