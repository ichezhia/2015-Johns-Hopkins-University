#ifndef INC_STUDENT
#define INC_STUDENT

#include "Course.h"
#include <string>
#include <vector>
using std::string;
using std::vector;

class Student {

public: 
	Student();

	//functions
	string addCourse(Course*);
	string dropCourse(int);
	void printCourseNames();
	void study(int);

	void takeCourseExam(int);

	void getRubric();
	void getGrades();
	void takeFinals();

private:
	Course course;
	
	Course* currentCourseArray[5];	
	vector<Course*> completedCourseVector;
	
};

#endif
