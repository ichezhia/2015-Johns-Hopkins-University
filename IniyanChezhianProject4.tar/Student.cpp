#include <iostream>
using std::cout;
using std::endl;

#include <cstring>
using std::strlen;
using std::strcpy;


#include <string>
using std::string;

#include "Student.h"
#include "Fact.h"
#include "Course.h"
#include "Project4_utilities.h"

Student::Student() {
	int i;
	for (i=0; i<5; i++) {
		currentCourseArray[i] = NULL;
	}
}

string Student::addCourse(Course *c) {
	int i;
    for (i=0; i<5; i++) {
         if(currentCourseArray[i] == NULL) {
              currentCourseArray[i] = c;
			return "Course added.";
         }
    }
	return "No more courses can be added.";
}

string Student::dropCourse(int courseNumber) {
	courseNumber--;

	if (currentCourseArray[courseNumber] == NULL) {
		return "Not a valid course number to drop.";
	} else {
		currentCourseArray[courseNumber] = NULL;
		return "Course dropped.";
	}
}

void Student::printCourseNames() {
	int i;

	cout << "Course List\n";	

	for (i=0; i<5; i++) {
		cout << i+1 << ". ";

		if (currentCourseArray[i] != NULL) {
		cout << currentCourseArray[i]->getCourseName() << " - " << currentCourseArray[i]->getSubjectName()  << "\n";
		} else {
			cout << "No Course Assigned\n";
		}
	}

}


void Student::study(int courseNumber) {
	courseNumber--;

	string subject = currentCourseArray[courseNumber]->getSubjectName();
	int fact_id;
	string fact;

	int i;

	i = Get_fact(subject, fact_id, fact);

	Fact* factTemp;
	factTemp = new Fact(fact_id, fact);

	currentCourseArray[courseNumber]->addFact(factTemp);

}

void Student::takeCourseExam(int courseNumber) {

	courseNumber--;
	
	int numberOfFacts;
	numberOfFacts = currentCourseArray[courseNumber]->takeExam();

	int courseGrade = 0;

	int i;

	if(numberOfFacts != 0) {
		for (int i=0; i<numberOfFacts; i++) {
			courseGrade += Get_points();
		
			if (courseGrade >= 100) {
				courseGrade = 100;
				break;
			}
		
		}	
	}

	currentCourseArray[courseNumber]->setNumericGrade(courseGrade);
	

	cout << "\n\nCourse grade: " << courseGrade;

	char grade = currentCourseArray[courseNumber]->calculateLetterGrade();
	
	cout << "\n\nCourse letter: " << grade;

	//move it to completed coursesArray
	completedCourseVector.push_back(currentCourseArray[courseNumber]);

	//remove from this array...set it to NULL
	currentCourseArray[courseNumber] = NULL;



}


void Student::getRubric() {

	int aCut;
	int bCut;
	int cCut;
	int dCut;

	Get_grade_cutoffs(aCut, bCut, cCut, dCut);
	
	cout << "\nThe grading rubric cutoffs are A:" << aCut << " B:" << bCut << " C:" << cCut 	<< " D:" << dCut << "\n";


}

void Student::getGrades() {
	//averages course grades for all current courses, then returns letter from rubric
	//float grade;
	//rubric.calcGrade(grade);


	//iterate through course obj in vector and recalc all letter grades
	//then print it nicely
	string course;
	char grade;	
	int i;

	for (i=0; i<completedCourseVector.size(); i++) {
		course = completedCourseVector.at(i)->getCourseName();
		grade = completedCourseVector.at(i)->calculateLetterGrade();
		
		cout << i+1 << ". " << course << " - " << grade << "\n";
	}
}


void Student::takeFinals() {
	//for all course classes, do takeExam(), then average the grades
	//send the grade to student.getGrade()
	//append GPA to current cum. GPA
	int i;
	/*
	int numberOfFacts;
	int courseGrade;
	int j;
	string course;
	char grade;	
	int k;*/

	for (i=0; i<5; i++) {

		if (currentCourseArray[i] != NULL) {
			cout << "\n\n" << currentCourseArray[i]->getCourseName() << ": ";
			takeCourseExam(i+1);
		}
	}	
/*
	for (k=0; k<completedCourseVector.size(); k++) {
		course = completedCourseVector.at(k)->getCourseName();
		grade = completedCourseVector.at(k)->calculateLetterGrade();

		cout << k+1 << ". " << course << " - " << grade << "\n";
	}
*/
}
