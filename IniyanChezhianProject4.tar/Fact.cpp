#include <iostream>
using std::cout;
using std::endl;

#include <cstring>
using std::strlen;
using std::strcpy;

#include <string>
using namespace std;

#include <stack>

#include "Fact.h"
#include "Project4_utilities.h"

Fact::Fact(int fact_id, string fact) {
	
	setFactID(fact_id);
	setFactValue(fact);
}

void Fact::setFactID(const int &i) {
	id = i;
}

void Fact::setFactValue(const string &f) {
	fact = f;
}

int Fact::getFactID() {
	return id;	
}

void Fact::printFactDetails() {

	cout << "Fact ID: " << id << "\nFact: " << fact;

}
