#include <iostream>
using std::cout;
using std::endl;

#include <cstring>
using std::strlen;
using std::strcpy;

#include <string>
using namespace std;

#include "Course.h"
#include "Project4_utilities.h"
#include "Fact.h"

Course::Course(string subject, string courseName, int numericGrade) {
	setSubjectName(subject);
	setCourseName(courseName);
	setNumericGrade(numericGrade);
}

void Course::setSubjectName(const string &s) {
	subject = s;
}

void Course::setCourseName(const string &c) {
	courseName = c;
}

void Course::setNumericGrade(const int &n) {
		numericGrade = n;
}

string Course::getCourseName() {
	return courseName;
}

string Course::getSubjectName() {
	return subject;
}

void Course::study() {
	//fact.storeFact(subject);
}



void Course::addFact(Fact* factPtr) {
	Fact* tempFact;

	//first fact
	if(s.empty()) {
		s.push(factPtr);

		factPtr->printFactDetails();
		return;
	}

	while(!s.empty()) {
	
	tempFact = s.top();
		if (tempFact->getFactID() == factPtr->getFactID()) {

			while(!temp.empty()) {

				s.push(temp.top());
				temp.pop();
			}	
			//return "failure: fact already exists";
		}	

		s.push(factPtr);

		factPtr->printFactDetails();
		break;
		//return "success: fact added";
	}
}


int Course::takeExam() {
	cout << "All Facts for Course Exam:\n";
	
	int factsCounter;
	factsCounter = 0;

	while(!s.empty()) {
		s.top()->printFactDetails();
		s.pop();
		factsCounter++;
	}

	return factsCounter;
}




char Course::calculateLetterGrade() {
	int aCut;
	int bCut;
	int cCut;
	int dCut;


	Get_grade_cutoffs(aCut, bCut, cCut, dCut);

	if (numericGrade>=aCut) {
		letterGrade = 'A';
	} else if (numericGrade >= bCut) {
		letterGrade = 'B';	
	} else if (numericGrade >= cCut) {
		letterGrade = 'C';	
	} else if (numericGrade >= dCut) {
		letterGrade = 'D';	
	} else {
		letterGrade = 'F';
	}


	return letterGrade;

}


