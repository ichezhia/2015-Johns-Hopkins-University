#ifndef INC_FACT
#define INC_FACT

class Fact {
public: 
	Fact(int id = 0, string fact = "");
	void setFactValue(const string &);
	void setFactID(const int &);
	int getFactID();
	void printFactDetails();
private:
	string fact;
	int id;


};

#endif
